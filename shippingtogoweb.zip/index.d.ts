declare module 'googlemaps';
